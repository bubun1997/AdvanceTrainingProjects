package com.soumyajit.exceptions;

public class LowBalanceException extends Exception{
	
	public LowBalanceException(String mssg) {
		
		super(mssg);
	}

}
