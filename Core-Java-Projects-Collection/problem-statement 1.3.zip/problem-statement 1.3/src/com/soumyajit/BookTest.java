package com.soumyajit;

import java.util.Scanner;

import com.soumyajit.books.Book;

public class BookTest {
	
	private static Book[] listOfBooks = null;
	
	public static void createBooks() {
		
		Scanner scannerObj = new Scanner(System.in);
		
		System.out.print("Enter Number of Books : ");
		int numberOfBooks = scannerObj.nextInt();
		
		listOfBooks = new Book[numberOfBooks];
		int len = listOfBooks.length;
		
		
		for(int i=0;i<len;i+=1) {
			
			scannerObj.nextLine();

			
			System.out.print("Enter Book Title : ");
			String title = scannerObj.nextLine();
			
			System.out.print("Enter Book price : ");
			double price = scannerObj.nextDouble();
			
			listOfBooks[i] = new Book();
			
			listOfBooks[i].setBookTitle(title);
			listOfBooks[i].setBookPrice(price);
			
			System.out.println("--------------------------");
		}
		
		scannerObj.close();
	}
	
	public static void showBooks() {
		
		System.out.println("*****Book Details are Listed Below******\n");
		
		for(Book book:listOfBooks) {
			
			System.out.print("Title -> "+book.getBookTitle()+
								" , "+"Price -> Rs. "+book.getBookPrice());
			
			System.out.println();
			System.out.println("------------------------------");
			
		}
			
	}

	public static void main(String[] args) {
		
		createBooks();
		showBooks();

	}

}
