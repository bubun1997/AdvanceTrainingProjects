package com.soumyajit.medicine;

public interface MedicineInfo {
	
	void displayLabel();

}
