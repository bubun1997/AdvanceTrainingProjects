package com.soumyajit;

import java.util.Arrays;
import java.util.List;

public class MergingArrays {

	public static int[] sortedMerge(int[] arr1 , int[] arr2) {
		
		int len1 = arr1.length;
		int len2 = arr2.length;
		
		int[] sortedArray = new int[len1 + len2];
		
		int index = 0;
		
		for(int i=0;i<len1;i+=1) {
			
			sortedArray[index] = arr1[i];
			index+=1;
		}
		
		for(int i=0;i<len2;i+=1) {
			
			sortedArray[index] = arr2[i];
			index+=1;
		}
		
		 Arrays.sort(sortedArray);
		 
		 return sortedArray;
	}
	public static void main(String[] args) {
		
		List<int[]> mergeSortedList1 = Arrays.asList(sortedMerge(new int[] {10,5,15}, new int[] {20,3,2}));
		
		System.out.print("1st Merge Sorted List is -> ");
		
		for(int[] arr:mergeSortedList1) {
			
			for(int num:arr) {
				
				System.out.print(num+" ");
			}
		}
		
		System.out.println();
		
		System.out.println("---------------------------------------------------");
		
		
		List<int[]> mergeSortedList2 = Arrays.asList(sortedMerge(new int[] {1,10,5,15}, new int[] {20,0,2}));
		
		System.out.print("2nd Merge Sorted List is -> ");
		
		for(int[] arr:mergeSortedList2) {
			
			for(int num:arr) {
				
				System.out.print(num+" ");
			}
		}

	}

}
