package com.soumyajit;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestCollection {

	public static boolean searchName(List<String> studentNames , String searchName) {
		
		for(String name:studentNames) {
			
			if(name.equalsIgnoreCase(searchName))
				return true;
		}
		
		return false;
	}
	public static void main(String[] args) {
		
		List<String> studentNames = new ArrayList<String>();
		
		studentNames.add("John");
		studentNames.add("Ram");
		studentNames.add("David");
		studentNames.add("Priya");
		studentNames.add("Rani");
		
		Scanner scannerObj = new Scanner(System.in);
		
		System.out.print("Enter Name to be searched : ");
		String searchName = scannerObj.nextLine();
		
		if(!searchName(studentNames, searchName)) {
			
			System.out.println("Student is not found with this name !!");
			scannerObj.close();
			return;
			
		}
		
		System.out.println("Student is available with this name...");
		
		scannerObj.close();

		
	}

}
