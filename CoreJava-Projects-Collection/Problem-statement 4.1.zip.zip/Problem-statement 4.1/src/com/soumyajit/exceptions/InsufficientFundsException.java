package com.soumyajit.exceptions;

public class InsufficientFundsException extends Exception{
	
	public InsufficientFundsException(String mssg) {
		
		super(mssg);
	}
	
	

}
