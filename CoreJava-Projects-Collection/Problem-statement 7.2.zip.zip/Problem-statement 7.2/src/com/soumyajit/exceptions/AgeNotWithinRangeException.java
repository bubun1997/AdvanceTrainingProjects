package com.soumyajit.exceptions;

public class AgeNotWithinRangeException extends Exception{
	
	public AgeNotWithinRangeException(String mssg) {
		
		super(mssg);
	}

}
