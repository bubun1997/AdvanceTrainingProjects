package com.soumyajit.counter;

import java.util.Scanner;

import com.soumyajit.storage.Storage;

public class Counter {
	
	private Storage storage;
	public Counter(Storage storage) {
		this.storage = storage;
		
	}
	public void addValues() {
		
		Thread th = new Thread() 
		{
			
			public void run() {
				
				int count = 0;
				
				while(true) {
					
					if(count>10)
						break;
					
					storage.storeValues(count);
					
					count+=1;
					
					
				}
				
				Storage.flag = true;
				synchronized (storage) {
					
					storage.notify();
					
				}
			}
			
		};
		
		th.start();
		
	}

}
