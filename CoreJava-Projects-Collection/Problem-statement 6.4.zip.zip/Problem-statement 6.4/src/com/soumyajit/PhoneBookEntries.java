package com.soumyajit;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PhoneBookEntries {
	
	public static void addPhoneBookEntries(Map<String, String> phonBookEntries , Scanner scannerObj) {
		
		int count=1;
		while(true) {
			
			if(count>5)
				break;
			
			System.out.print("Enter Name of "+count+" person : ");
			String name=  scannerObj.nextLine().toLowerCase();
			System.out.print("Enter Phone Number of "+count+" person : ");
			String number = scannerObj.nextLine();
			
			phonBookEntries.put(name, number);
			
			count+=1;
		}
	}
	
	public static String getPhoneNumber(Map<String, String> phoBookEntries , String name) {
		
		String phoneNumber = null;
		
				
		if(phoBookEntries.containsKey(name))
			phoneNumber = phoBookEntries.get(name);
		
		
		
		return phoneNumber;
	}

	public static void main(String[] args) {
		
		Scanner scannerObj = new Scanner(System.in);
		
		Map<String, String> phoneBookEntries = new HashMap<String,String>();
		
		System.out.print("i) Add new Phone book entry , ii) Search Phone number , iii) Quit\n");
		
		
		
		first:while(true) {
			
			System.out.print("Enter your choice : ");
			String choice = scannerObj.nextLine();
			switch(choice) {
			
				case "i" : addPhoneBookEntries(phoneBookEntries, scannerObj);
							System.out.println();
							continue;
					       
						   
				case "ii" :
						 	if(phoneBookEntries.size() != 0) {
								System.out.print("Enter Name of the Person : ");
								String name = scannerObj.nextLine().toLowerCase();
								String phoneNumber = getPhoneNumber(phoneBookEntries,  name);
								if(phoneNumber !=null ) {
									System.out.println("Phone Number of "+name+" is -> "+phoneNumber);
									System.out.println();
									continue;
								}
								System.out.println("No Entry available with this name !!");
								System.out.println();
								continue;
							
						 	}
						 	System.out.println("Your Phone Book is Empty , Please add some Entries !!");
						 	System.out.println();
						 	continue;
							
				case "iii" : break first;
			}
		}
		
		System.out.println("Your Contact List -> "+phoneBookEntries);

	}

}
