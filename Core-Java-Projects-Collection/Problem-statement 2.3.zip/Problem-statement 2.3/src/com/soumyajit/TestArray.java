package com.soumyajit;

public class TestArray {

	public static int getSum(int[] arr) {
		
		int sum =0;
		
		for(int i=0;i<14;i+=1) {
			sum+=arr[i];
		}
		
		return sum;
	}
	
	public static double getAverage(int[] arr) {
		
		double sum =0;
		for(int x:arr) {
			
			sum+=x;
		}
		
		return sum/arr.length;
	}
	
	public static int getMin(int[] arr) {
		
		int min = arr[0];
		for(int x:arr) {
			if(x<min)
				min=x;
		}
		return min;
	}
	public static void main(String[] args) {
		
		int[] A = {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		
		int sum = getSum(A);
		
		int avg = (int) getAverage(A);
		
		int min = getMin(A);
		
		A[15] = sum;
		
		A[16] = avg;
		
		A[17] = min;
		
		System.out.println("A[15] -> "+A[15]);
		System.out.println("A[16] -> "+A[16]);
		System.out.println("A[17] -> "+A[17]);

		

	}

}
