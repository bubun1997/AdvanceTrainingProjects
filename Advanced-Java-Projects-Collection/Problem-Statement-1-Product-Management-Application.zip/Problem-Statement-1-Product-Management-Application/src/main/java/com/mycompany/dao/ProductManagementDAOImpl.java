package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAOImpl implements ProductManagementDAO {
	
	private static final Connection CONNECTION;
	
	static {
		 
		CONNECTION = DBUtil.getConnection();
	}

	@Override
	public List<Product> viewProducts() {
		
		List<Product> allProducts = new ArrayList<>();
		
		try {
			PreparedStatement statement = CONNECTION.prepareStatement("SELECT * FROM PRODUCT");
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				
				Long productId = resultSet.getLong(1);
				String productName = resultSet.getString(2);
				double productPrice = resultSet.getDouble(3);
				
				Product product = new Product();
				
				product.setProductId(productId);
				product.setProductName(productName);
				product.setProductPrice(productPrice);
				
				allProducts.add(product);
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return allProducts;
	}
	
	@Override
	public int addProduct(Long productId, String productName, double productPrice) {
		    
		int result = 0;
        try {
            PreparedStatement statement = CONNECTION.prepareStatement("INSERT INTO PRODUCT VALUES(?,?,?)");

			statement.setLong(1, productId);
			statement.setString(2, productName);
	        statement.setDouble(3, productPrice);
	        
	        result = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
        
		return result;
	}
	

	@Override
	public int updateProduct(Long productId, String productName, double productPrice) {
		
		int result = 0;
		
		try {
			PreparedStatement statement = CONNECTION.prepareStatement("UPDATE PRODUCT SET "+ "productName = ? ,"
																		+ " productPrice = ?"+ " WHERE productId = ?");
			
			statement.setLong(3, productId);
			statement.setString(1, productName);
			statement.setDouble(2, productPrice);
			
			result = statement.executeUpdate();
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int deleteProduct(Long productId) {
		
		int result = 0;
		
		try {
			
			PreparedStatement statement = CONNECTION.prepareStatement("DELETE FROM PRODUCT WHERE productId = ?");
			
			statement.setLong(1, productId);
			
			result = statement.executeUpdate();
			
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Product searchProduct(Long productId) {
		
		Product product = null;
		try {
			
			PreparedStatement statement = CONNECTION.prepareStatement("SELECT * FROM PRODUCT WHERE productId = ?");
			
			statement.setLong(1, productId);
			
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				
				String productName = resultSet.getString(2);
				double productPrice = resultSet.getDouble(3);
				
				 product = new Product();
				 
				 product.setProductId(productId);
				 product.setProductName(productName);
				 product.setProductPrice(productPrice);
				
				
			}
			
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		return product;
	}

	@Override
	public void closeConnection() {
		
		try {
			CONNECTION.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}




	

}
