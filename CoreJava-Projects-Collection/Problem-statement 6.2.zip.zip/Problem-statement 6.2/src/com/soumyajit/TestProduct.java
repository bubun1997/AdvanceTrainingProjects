package com.soumyajit;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.soumyajit.product.Product;

public class TestProduct {
	
	public static void addProducts(Set<Product> listOfProducts,Scanner scannerObj) {
		
		Long id = 1001L;
		
		while(true) {
			if(id == 1011L)
				break;
			
			System.out.print("Enter Product Name : ");
			String productName = scannerObj.nextLine();
			
			Product product = new Product(id, productName);
			
			listOfProducts.add(product);
			id+=1;
			
			
		}
		
	}

	public static boolean searchProduct(Set<Product> listOfProducts , Product searchProduct) {
		
		boolean isPresent = false;
		
		if(listOfProducts.contains(searchProduct))
			isPresent = true;
		
		return isPresent;
		
		
	}
	
	public static boolean deleteProduct(Set<Product> listProducts , Scanner scannerObj) {
		
		System.out.print("Enter Product Id to be deleted : ");
		Long id = scannerObj.nextLong();
		for(Product product:listProducts) {
			
			if(product.getProductId().equals(id)) {
				listProducts.remove(product);
				return true;
			}
		}
		
		return false;
	}
	public static void main(String[] args) {
		
		Set<Product> listOfProducts = new HashSet<>();
		Scanner scannerObj = new Scanner(System.in);

		
		addProducts(listOfProducts,scannerObj);
		
		
		System.out.print("Enter Product Id to be searched : ");
		
		Long productId = scannerObj.nextLong();
		
		System.out.print("Enter Product name to be searched : ");
		
		scannerObj.nextLine();
		
		String productName = scannerObj.nextLine();
		
		Product searchProduct = new Product(productId,productName);
		
		if(searchProduct(listOfProducts,searchProduct))
			System.out.println("Product found");
		
		else 
			System.out.println("Product Not found");
		
		if(deleteProduct(listOfProducts, scannerObj)) {
			System.out.println();
			System.out.println("Final Products List after deleting -> "+listOfProducts);
		
		}
		else{
			System.out.println("Product Not found , can't delete");
		}
				
		scannerObj.close();
		

	}

}
