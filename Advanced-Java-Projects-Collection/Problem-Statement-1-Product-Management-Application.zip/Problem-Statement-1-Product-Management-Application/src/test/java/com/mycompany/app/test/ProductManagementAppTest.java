package com.mycompany.app.test;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.jupiter.api.BeforeAll;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.dao.ProductManagementDAOImpl;
import com.mycompany.domain.Product;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class ProductManagementAppTest 
    extends TestCase
{
    
	private static final ProductManagementDAO DAO = new ProductManagementDAOImpl();
	
	
	
    public ProductManagementAppTest( String testName )
    {
        super( testName );
    }

   
    public static Test suite()
    {
        return new TestSuite( ProductManagementAppTest.class );
    }

   
    public void testViewProducts() {
    	
    	 List<Product> allProducts = DAO.viewProducts();
    	 
    	 if(allProducts.isEmpty()) {
    		 assertEquals("empty","empty");
    	 }
    	 else {
    		 assertTrue(allProducts.size()>0);
    	 }
    }
    
    
    public void testGetSingleProduct() {
    	
    	
    	
    	Product pro = DAO.searchProduct(101L);
    	
    	if(pro!=null) {
    		
    		assertNotNull(pro);
    	}
    	else {
    		assertNull(pro);
    	}
    	
    }
    
    
}
