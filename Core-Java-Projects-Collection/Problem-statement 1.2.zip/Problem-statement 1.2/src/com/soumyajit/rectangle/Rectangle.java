package com.soumyajit.rectangle;

public class Rectangle {
	
	private double length;
	
	private double breadth;
	
	private double area;

	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	public Rectangle() {
		super();
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	
	public void calculateArea() {
		
		this.area = this.length * this.breadth;
	}
	
	public double getArea() {
		
		this.calculateArea();
		
		return this.area;
	}
	
	

}
