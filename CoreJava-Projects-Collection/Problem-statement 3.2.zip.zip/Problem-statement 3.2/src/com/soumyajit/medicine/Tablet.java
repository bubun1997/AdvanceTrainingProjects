package com.soumyajit.medicine;

public class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		
		System.out.println(this.getClass().getSimpleName()+" -> Store In a cool dry place");
		
	}

}
