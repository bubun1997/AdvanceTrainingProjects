package com.soumyajit.printer;

import com.soumyajit.storage.Storage;

public class Printer {
	
	private Storage storage;
	public Printer(Storage storage) {
		this.storage = storage;
		
	}
	
	public void readValues() {
		
		Thread th = new Thread()
				{
					
			       public void run() {
			    	   
			    	   storage.readValues();
			       }
				};
				
				th.start();
	}

}
