package com.soumyajit;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.soumyajit.employee.Employee;

public class TestEmployee {

	public static void addInput(List<Employee> listOfEmployees , Scanner scannerObj) {
		
		int count = 1;
		while(true) {
			
			if(count>5)
				break;
			
			System.out.print("Enter Employee No : ");
			
			Long employeeNumber = scannerObj.nextLong();
			
			scannerObj.nextLine();
			
			System.out.print("Enter Employee name : ");
			
			String employeename = scannerObj.nextLine();
			
			System.out.print("Enter Employee address : ");
			
			String employeeAddress = scannerObj.nextLine();
			
			Employee employee = new Employee(employeeNumber, employeename, employeeAddress);
			
			listOfEmployees.add(employee);
			
			System.out.println();
			
			count+=1;
		}
	}
	
	public static void display(List<Employee> listEmployees) {
		
		ListIterator<Employee> iterator = listEmployees.listIterator();
		
		System.out.println();
		System.out.println("****** Employee Details in forward direction *****");
		
		while(iterator.hasNext())
		{
			Employee emp = iterator.next();
			
			System.out.println("Emp No -> "+emp.getEmployeeNumber()+
					" ,"+ "	Name -> "+emp.getEmployeeName()
					+" , "+ "Address -> "+emp.getEmployeeAddress());
		}
		
		System.out.println();
		
		System.out.println("***** Employee Details in Backward Direction ****");
		
		while(iterator.hasPrevious()) {
			
			Employee emp = iterator.previous();
			
			System.out.println("Emp No -> "+emp.getEmployeeNumber()+
					" ,"+ "	Name -> "+emp.getEmployeeName()+
					" , "+ "Address -> "+emp.getEmployeeAddress());
			
			
		}
		
		
		
	}
	public static void main(String[] args) {
		
		Scanner scannerObj = new Scanner(System.in);
		
		List<Employee> listOfEmployees = new LinkedList<>();
		
		addInput(listOfEmployees, scannerObj);
		
		display(listOfEmployees);
		
		scannerObj.close();

	}

}
