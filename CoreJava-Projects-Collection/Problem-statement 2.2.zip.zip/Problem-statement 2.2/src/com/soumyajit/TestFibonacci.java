package com.soumyajit;

public class TestFibonacci {
	
	public static void main(String[] args) {
		
		if(args.length == 2) {
			
			int first = Integer.parseInt(args[0]);
			int second = Integer.parseInt(args[1]);
			
			System.out.print(first+" "+second+" ");
			
			for(int i=1;i<=13;i++) {
				
				int sum = first+second;
				System.out.print(sum+" ");
				first = second;
				second = sum;
			}
		}
	}

}
