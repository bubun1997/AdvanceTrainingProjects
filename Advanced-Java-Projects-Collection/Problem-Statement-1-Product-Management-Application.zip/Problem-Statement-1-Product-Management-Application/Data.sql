create database productdb;

use productdb;

create table product
(
    productId bigint(5),
    ProductName varchar(20),
    ProductPrice double(8,2),
	constraint product_pk primary key(productid)
    
);


