package com.soumyajit.medicine;

public class Ointment implements MedicineInfo{

	@Override
	public void displayLabel() {
		
		System.out.println(this.getClass().getSimpleName()+" -> For external use only");
		
	}

}
