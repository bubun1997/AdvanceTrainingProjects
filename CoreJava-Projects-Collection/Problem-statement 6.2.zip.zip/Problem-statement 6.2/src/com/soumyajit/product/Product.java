package com.soumyajit.product;

public class Product {
	
	private Long productId;
	
	private String productName;

	public Product(Long productId, String productname) {
		super();
		this.productId = productId;
		this.productName = productname;
	}
	
	
	
	public Long getProductId() {
		return productId;
	}



	public String getProductName() {
		return productName;
	}



	public int hashCode() {
		
		return (int)(long) this.productId;
	}
	
	public boolean equals(Object obj) {
		
		if(this == obj)
			return true;
		
		else if(obj instanceof Product) {
			
			Product pro = (Product) obj;
			if(this.productName.equalsIgnoreCase(pro.productName))
				return true;
			else
				return false;
			
		}
		
		return false;
		
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]";
	}
	
	
	

}
