package com.soumyajit;

public class TestStringManipulations {

	public static void main(String[] args) {
		
		String str1 = "MPHASIS";
		int length = str1.length();
		
		System.out.println(str1);
		
		for(int i=1;i<=length;i+=1) {
			
			String str2 = "";
			
			for(int j=1;j<length;j+=1) {
				
				str2+=str1.charAt(j);
			}
			str2+=str1.charAt(0);
			
			str1 = str2;
			
			System.out.println(str1);
			
		}

	}

}
