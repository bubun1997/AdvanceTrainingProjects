package com.soumyajit.exceptions;

public class FieldBlankException extends Exception{
	
	public FieldBlankException(String mssg) {
		
		super(mssg);
	}

}
