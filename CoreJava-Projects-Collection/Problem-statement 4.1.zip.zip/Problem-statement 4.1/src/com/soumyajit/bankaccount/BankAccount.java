package com.soumyajit.bankaccount;

import com.soumyajit.exceptions.InsufficientFundsException;
import com.soumyajit.exceptions.InvalidAccountException;
import com.soumyajit.exceptions.LowBalanceException;
import com.soumyajit.exceptions.NegativeAmountException;

public class BankAccount {
	
	private Long accNo;
	
	private String custName;
	
	private String accType;
	
	private float balance;
	
	
	
	public BankAccount(Long accNo, String custName, String accType, float balance) throws LowBalanceException, InvalidAccountException, NegativeAmountException {
		
		if(accType.equalsIgnoreCase("savings")) {
			
			if(balance<0)
				throw new NegativeAmountException("Balance can't be negative...");
			
			else if(balance<1000)
				throw new LowBalanceException("Your balance is Low...");
			
			this.accNo = accNo;
			this.custName = custName;
			this.accType = accType;
			this.balance = balance;
			
		}
		else if(accType.equalsIgnoreCase("current")) {
			
			if(balance<0)
				throw new NegativeAmountException("Balance can't be negative...");
			
			
			else if(balance<5000)
				throw new LowBalanceException("Your balance is very Low...");
			
			this.accNo = accNo;
			this.custName = custName;
			this.accType = accType;
			this.balance = balance;
		}
		
		else
			throw new InvalidAccountException("No such Account...");
		
	}

	public void deposit(float amt) throws NegativeAmountException {
		
		if(amt<0) {
			
			throw new NegativeAmountException("Amount can't be negative...");
		}
		
		this.balance += amt;
		
	}
	
	public void withdraw(float amt) throws InsufficientFundsException {
		
		if(this.accType.equalsIgnoreCase("savings")) {
			
			if(this.balance<1000)
				throw new InsufficientFundsException("Insufficient balance ,can't withdraw !!");
			
			else if(amt>this.balance)
				throw new InsufficientFundsException("Insufficient balance ,can't withdraw !!");
			
			else
				this.balance -= amt;
			
			return;

		}
		
		else if(this.accType.equalsIgnoreCase("current")) {
			
			if(this.balance<5000)
				throw new InsufficientFundsException("Insufficient balance ,can't withdraw !!");
			
			else if(amt>this.balance)
				throw new InsufficientFundsException("Insufficient balance ,can't withdraw !!");
			
			else
				this.balance -= amt;
			
			return;

		}
		
	}
	
	public float getBalance() throws LowBalanceException {
		
		if(this.accType.equalsIgnoreCase("savings")) {
			
			if(this.balance<1000)
				throw new LowBalanceException("Your balance is very low..");
			
		}
		
		else if(this.accType.equalsIgnoreCase("current")) {
			
			if(this.balance<5000)
				throw new LowBalanceException("Your balance is very low..");
			
		}
		
		return this.balance;
		
	}

}
