package com.soumyajit.exceptions;

public class InvalidAccountException extends Exception{
	
	public InvalidAccountException(String mssg) {
		
		super(mssg);
	}

}
