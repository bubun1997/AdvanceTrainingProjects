package com.mycompany.app;

import java.util.List;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.dao.ProductManagementDAOImpl;
import com.mycompany.domain.Product;

public class ProductManagementApp 
{
	private static final ProductManagementDAO DAO = new ProductManagementDAOImpl();
	
    public static void main( String[] args )
    {
    	
    	Scanner scannerObj = new Scanner(System.in);
    	
    	System.out.println("**** Welcome To Product Management App ******\n");
    	
    	
    	first:while(true) {
    		
        	System.out.println("**** You can do following operations ******\n");

    		
    		System.out.println("A. View Products \n"
        			+ "B. Add Products \n"
        			+ "C. Update Product \n"
        			+ "D. Delete Product \n"
        			+ "E. Search Product \n"
        			+ "F. Exit");
        	
        	System.out.println("==============================================");
        	
        	System.out.print("Enter an Option : ");
        	
        	String choice = scannerObj.nextLine().toUpperCase().charAt(0)+"";
        	
        	System.out.println();
        	
        	switch(choice) {
        	
        		case "A" : List<Product> allProducts = DAO.viewProducts();
        		
        					if(allProducts.isEmpty()) {
        						
        						System.out.println("Currently No products are there !!\n");
        						continue;
        					}
        				   
        				   for(Product product:allProducts) {
        					   
        					   System.out.println("Product Id : "+product.getProductId());
        					   System.out.println("Product Name : "+product.getProductName());
        					   System.out.println("Product Price : "+product.getProductPrice()+"\n");
        					   
        				   }
        				   continue;
        				   
        		case "B" : System.out.print("Enter Product Id : ");
        				   Long productIdToBeAdded = scannerObj.nextLong();
        				   scannerObj.nextLine();
        				   System.out.print("Enter Product Name : ");
        				   String productNameToBeAdded = scannerObj.nextLine();
        				   System.out.print("Enter Product Price : ");
        				   double productPriceToBeAdded = scannerObj.nextDouble();
        				   
        				   int rowsInserted = DAO.addProduct(productIdToBeAdded, productNameToBeAdded, productPriceToBeAdded);
        				   
        				   if(rowsInserted>0) {
        					   System.out.println("Product added successfully...\n");
        					   scannerObj.nextLine();
        					   continue;
        				   }
        				   else {
        					   System.out.println("Product Not addedd....\n");
        					   scannerObj.nextLine();
        					   continue;
        				   }
        				   
        				   
        		case "C" : System.out.print("Enter product Id to be updated : ");
        		           Long productIdToBeUpdated = scannerObj.nextLong();
        				   scannerObj.nextLine();
        				   System.out.print("Enter New Product Name : ");
        		           String productNameToBeUpdated = scannerObj.nextLine();
        		           System.out.print("Enter New Product Price : ");
        		           double productPriceTobeUpdated = scannerObj.nextDouble();
        		           
        		           int rowsUpdated = DAO.updateProduct(productIdToBeUpdated, productNameToBeUpdated, productPriceTobeUpdated);
        		           
        		           if(rowsUpdated>0) {
        		        	   System.out.println("Product updated successfully...\n");
        					   scannerObj.nextLine();
        					   continue;
        		        	   
        		           }
        		           else {
        		        	   System.out.println("Sorry can't update as no product is available with this id....\n");
        					   scannerObj.nextLine();
        					   continue;
        		           }
        		           
        		case "D" : System.out.print("Enter Product Id To be deleted : ");
        				   Long productIdToBeDeleted = scannerObj.nextLong();
        				   
        				   int rowsDeleted = DAO.deleteProduct(productIdToBeDeleted);
        				   
        				   if(rowsDeleted>0) {
        		        	   System.out.println("Product deleted successfully...\n");
        					   scannerObj.nextLine();
        					   continue;
        		        	   
        		           }
        		           else {
        		        	   System.out.println("Sorry can't delete , no product available with this id....\n");
        					   scannerObj.nextLine();
        					   continue;
        		           }
        				   
        				   
        		case "E" : System.out.print("Enter Product Id To be searched : ");
        				   Long productIdToBeSearched = scannerObj.nextLong();
        				   
        				   Product product = DAO.searchProduct(productIdToBeSearched);
        				   
        				   if(product != null) {
        					   System.out.println("Product Id : "+product.getProductId());
        					   System.out.println("Product Name : "+product.getProductName());
        					   System.out.println("Product Price : "+product.getProductPrice());
        					   scannerObj.nextLine();
        					   continue;
        				   }
        				   else {
        					   System.out.println("Product Not Found with this id...\n");
        					   scannerObj.nextLine();
        					   continue;
        				   }
        				   
        		case "F" : 	break first;
        		
        		default :   System.out.println("Invalid Option !!");
        					continue;
        	}
        	
    		
    	}
    	
    	
    	DAO.closeConnection();
    	scannerObj.close();
    	
    	System.out.println("****** Thank You ******");

    	
    	
    }
}
