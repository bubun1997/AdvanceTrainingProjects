package com.soumyajit.medicine;

public class Syrup implements MedicineInfo{

	@Override
	public void displayLabel() {
		
		System.out.println(this.getClass().getSimpleName()+" -> Consume as directed by the physician");
		
	}

}
