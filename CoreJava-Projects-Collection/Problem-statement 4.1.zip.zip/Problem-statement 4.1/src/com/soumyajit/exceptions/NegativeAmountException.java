package com.soumyajit.exceptions;

public class NegativeAmountException extends Exception{
	
	public NegativeAmountException(String mssg) {
		
		super(mssg);
	}

}
