package com.soumyajit.employee;

public class Employee {
	
	private Long employeeNumber;
	
	private String employeeName;
	
	private String employeeAddress;

	public Employee(Long employeeNumber, String employeeName, String employeeAddress) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
	}

	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + "]";
	}

	public Long getEmployeeNumber() {
		return employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	
	
	

}
