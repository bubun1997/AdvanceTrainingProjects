package com.soumyajit;

import java.util.Scanner;

import com.soumyajit.instruments.Flute;
import com.soumyajit.instruments.Guitar;
import com.soumyajit.instruments.Instrument;
import com.soumyajit.instruments.Piano;

public class TestInstruments {

	public static void main(String[] args) {
		
		Instrument[] instruments = new Instrument[10];
		
		int len = instruments.length;
		
		Scanner scannerObj = new Scanner(System.in);
		
		int count = 0;
		
		while(true) {
			
			if(count==len)
				break;
			
			System.out.print("Enter instrument type : ");
			
			String instrument = scannerObj.nextLine().toLowerCase();
			
			switch(instrument) {
			
			   case "piano" : 
				              instruments[count] = new Piano();
				              break;
				              
			   case "guitar" : instruments[count] = new Guitar();
			                   break;
			    
			   case "flute" : instruments[count] = new Flute();
			                  break;
			                  
			    default : 	  System.out.println("No such object!!");
			                  continue;
			          
			}
			
			count+=1;
		}
		
		System.out.println();
				
		System.out.println("******See Your Instruments playing*****\n");
		
		for(Instrument instrument:instruments) {
			
			instrument.play();
		}
		
		System.out.println("-----------------------------------------");
		count=0;
		for(Instrument instrument:instruments) {
			
			if(instrument instanceof Piano)
				System.out.println("Index ["+count+"] -> "+Piano.class.getSimpleName());
			
			else if(instrument instanceof Flute)
				System.out.println("Index ["+count+"] -> "+Flute.class.getSimpleName());
			
			else
				System.out.println("Index ["+count+"] -> "+Guitar.class.getSimpleName());

			
			count+=1;

				
		}
		
		scannerObj.close();
		
		
	}

}
