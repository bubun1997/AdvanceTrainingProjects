package com.soumyajit;

public class TestString {
	
	public static void main(String[] args) {
		
		for(String str:args) {
			
			System.out.println("Length -> "+str.length());
			
			System.out.println("String in Upper case -> "+str.toUpperCase());
			
			System.out.println("IsPalindrome ? -> "+isPalindrome(str));
			
			System.out.println("-------------------------------------------");
			
			
		}
	}
	
	public static boolean isPalindrome(String input) {
		
		boolean flag = false;
		
		String pal = "";
		
		for(int i=input.length()-1;i>=0;i-=1) {
			
			pal+=input.charAt(i);
		}
		if(pal.equals(input))
			flag = true;
		
		return flag;
	}

}
