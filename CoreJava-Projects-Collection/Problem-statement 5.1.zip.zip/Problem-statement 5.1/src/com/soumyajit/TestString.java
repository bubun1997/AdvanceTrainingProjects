package com.soumyajit;

public class TestString {

	public static void main(String[] args) {
		
		String str = "JAVA is Simple";
		String[] arr = str.split(" ");
		int len = arr.length;
		
		
		System.out.println("Output 1 -> "+str.toUpperCase());
		System.out.println("Output 2 -> "+str.toLowerCase());
		
		System.out.print("Output 3 -> ");
		for(String s:arr) {
			
			System.out.print(s.charAt(0)+" ");
		}
		System.out.println();
		
		System.out.print("Output 4 -> ");
		
		for(int i=len-1;i>=0;i-=1) {
			
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		System.out.print("Output 5 -> ");
		
		for(String s:arr) {
			
			System.out.print(new StringBuffer(s).reverse()+" ");
		}
		
		System.out.println();
		
		System.out.println("Output 6 -> "+str.length());

	}

}
