package com.soumyajit;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ClimbingStairs {

    public static int climbStairs(int n) {
    	
    	Map<Integer, Integer> map = new HashMap<>();

        if(map.containsKey(n)){
            return map.get(n);
        }
        
        int result;
        if(n<=2) result = n;
        else{
            result = climbStairs(n-1)+climbStairs(n-2);
        }
        map.put(n,result);
        return result;
    }
	public static void main(String[] args) {
		
		Scanner scannerObj = new Scanner(System.in);
		
		System.out.print("Enter Number of steps : ");
		
		int steps = scannerObj.nextInt();
		
		System.out.println("Output -> "+climbStairs(steps));
		
		scannerObj.close();

	}

}
