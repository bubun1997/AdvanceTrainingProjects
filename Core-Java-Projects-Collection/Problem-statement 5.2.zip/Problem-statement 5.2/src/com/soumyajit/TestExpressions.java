package com.soumyajit;

import java.util.Scanner;
import java.util.StringTokenizer;

public class TestExpressions {

	public static void main(String[] args) {
		
		Scanner scannerObj = new Scanner(System.in);
		
		System.out.print("Enter Input : ");
		String inputString = scannerObj.nextLine();
		
		StringTokenizer strToken = new StringTokenizer(inputString," ");
		while(strToken.hasMoreTokens()) {
			
			System.out.println(strToken.nextToken());
		}
		
		scannerObj.close();

	}

}
