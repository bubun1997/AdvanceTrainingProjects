package com.soumyajit;

import java.util.Scanner;

public class EvenNumbersList {

	public static void main(String[] args) {
		
		Scanner scannerObj = new Scanner(System.in);
		
		System.out.print("Enter the Upper bound : ");
		int upperBound = scannerObj.nextInt();
		
		System.out.print("Even Numbers -> ");
		for(int i=2;i<=upperBound;i+=1) {
			
			if(i%2 == 0)
				System.out.print(i+" ");
			
		}
		
		scannerObj.close();

	}

}
