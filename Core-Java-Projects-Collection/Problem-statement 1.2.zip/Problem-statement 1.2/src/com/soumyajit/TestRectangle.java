package com.soumyajit;

import java.util.Scanner;

import com.soumyajit.rectangle.Rectangle;

public class TestRectangle {

	public static void main(String[] args) {
		
		Rectangle[] rectangleObjects = new Rectangle[5];
		
		Scanner scannerObj = new Scanner(System.in);
		
		int count = 0;
		while(true) {
			
			if(count == rectangleObjects.length)
				break;
			
			System.out.print("Enter Length : ");
			
			double length = scannerObj.nextDouble();
			
			System.out.print("Enter Breadth : ");

			double breadth = scannerObj.nextDouble();
			
			
			rectangleObjects[count] = new Rectangle(length, breadth);
			
			count+=1;
			
			System.out.println("---------------------------");
			
		}
		
		for(Rectangle rectangle:rectangleObjects)
			System.out.println("Area -> "+rectangle.getArea()+" Sq.units");
		
		scannerObj.close();

	}

}
