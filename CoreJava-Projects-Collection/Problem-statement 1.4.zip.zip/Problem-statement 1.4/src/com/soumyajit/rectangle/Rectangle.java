package com.soumyajit.rectangle;

public class Rectangle {
	
	private double length = 1.0D;
	
	private double breadth = 1.0D;
	
	private double area;
	
	private double perimeter;

	public Rectangle() {
		super();
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		
		if(length>0.0 && length<20.0)
			this.length = length;
	}

	public double getBreadth() {
		return breadth;
	}

	public void setBreadth(double breadth) {
		
		if(breadth>0.0 && breadth<20.0)
			this.breadth = breadth;
	}
	
	public void calculateArea() {
		
		this.area = this.length * this.breadth;
	}
	
	public void calculatePerimeter() {
		
		this.perimeter = 2 * (this.length + this.breadth);
		
	}
	
	public double getArea() {
		
		this.calculateArea();
		
		return this.area;
	}
	
	public double getPerimeter() {
		
		this.calculatePerimeter();
		
		return this.perimeter;
	}
	
	

}
