package com.soumyajit.instruments;

public abstract class Instrument {
	
	public abstract void play();

}
