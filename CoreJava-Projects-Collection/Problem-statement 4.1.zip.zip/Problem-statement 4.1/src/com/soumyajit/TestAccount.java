package com.soumyajit;

import com.soumyajit.bankaccount.BankAccount;
import com.soumyajit.exceptions.InsufficientFundsException;
import com.soumyajit.exceptions.InvalidAccountException;
import com.soumyajit.exceptions.LowBalanceException;
import com.soumyajit.exceptions.NegativeAmountException;

public class TestAccount {

	public static void main(String[] args) {
		
		BankAccount account1 = null;
		BankAccount account2 = null;

		
		try {
			 account1 = new BankAccount(10001L, "Ram Yadav", "Savings", 3500.00f);
			 account2 = new BankAccount(1002L, "Mohit tiwari", "Current", 5523.00f);
			 
		} catch (LowBalanceException | NegativeAmountException | InvalidAccountException ex) {
			ex.printStackTrace();
		}
		
		try {
			if(account1 !=null && account2!=null) {
			System.out.println("Account 1 balance -> "+account1.getBalance());
			System.out.println("Account 2 balance -> "+account2.getBalance());

		    account1.deposit(250.00f);
		    
		    account2.deposit(120.35f);
		    
		    System.out.println("Account 1 balance after Deposit -> "+account1.getBalance());
			System.out.println("Account 2 balance after Deposit -> "+account2.getBalance());
			
			account1.withdraw(520.00f);
			account2.withdraw(650.00f);
			
			 System.out.println("Account 1 balance after Withdraw -> "+account1.getBalance());
			 System.out.println("Account 2 balance after Withdraw -> "+account2.getBalance());
			
		}
			
		} catch (LowBalanceException | NegativeAmountException | InsufficientFundsException ex) {
			ex.printStackTrace();
		}
		

	}

}
