package com.soumyajit;

import java.util.Scanner;

import com.soumyajit.medicine.MedicineInfo;
import com.soumyajit.medicine.Ointment;
import com.soumyajit.medicine.Syrup;
import com.soumyajit.medicine.Tablet;

public class TestMedicine {

	public static void main(String[] args) {
		
		MedicineInfo[] medicines = new MedicineInfo[10];
		
		Scanner scannerObj = new Scanner(System.in);
		
		int count = 0;
		
		int len = medicines.length;
		
		while(true) {
			
			if(count == len)
				break;
			
			System.out.print("Enter 1 , 2 or 3 : ");
			int choice = scannerObj.nextInt();
			
			switch(choice) {
			
			case 1: medicines[count] = new Tablet();
					break;
			case 2: medicines[count] = new Syrup();
					break;
					
			case 3: medicines[count] = new Ointment();
					break;
					
			 default:System.out.println("Wrong Choice !!");
			  		 continue;
			
			}
			
			count+=1;

		}
		
		System.out.println("****See your Medicine behaviour below******\n");
		
		for(MedicineInfo medicine:medicines) {
			
			 medicine.displayLabel();
		}
		
		scannerObj.close();

	}

}
