package com.mycompany.dao;

import java.util.List;

import com.mycompany.domain.Product;

public interface ProductManagementDAO {
	
	List<Product> viewProducts();
	
	int addProduct(Long productId , String productName , double productPrice);
	
	int updateProduct(Long produId , String productName , double productPrice);
	
	int deleteProduct(Long productId);
	
	Product searchProduct(Long productId);
	
	void closeConnection();
	
	

}
